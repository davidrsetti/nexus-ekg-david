# NEXUS — Enterprise Knowledge Graph Platform

## Architecture

```
nexus/
├── config/
│   ├── settings.py          # All env/config centralised
│   └── ontology_prefixes.py # Shared SPARQL prefix registry
│
├── core/
│   ├── stardog_client.py    # Raw HTTP SPARQL client
│   ├── ontology.py          # Ontology context loader & cacher
│   ├── nl_to_sparql.py      # NL→SPARQL pipeline (tiered models)
│   ├── clarifier.py         # Human-in-the-loop intent mapper
│   └── answer_engine.py     # NL answer with reasoning
│
├── domains/
│   ├── hr.py                # People, org, managers (Workday)
│   ├── cmdb.py              # Applications, infra (ServiceNow)
│   ├── ea.py                # Capabilities, architecture (Orbus)
│   ├── data_governance.py   # Assets, lineage, classification (Unity/Collibra)
│   ├── security.py          # Roles, access, certs (Entra/SailPoint)
│   ├── denodo.py            # Virtual graph, live data federation
│   └── documents.py         # Unstructured content (Veeva/SharePoint)
│
├── agents/
│   ├── registry.py          # Agent catalogue & capability lookup
│   ├── context_provider.py  # Context bundle for agent consumption
│   ├── guard.py             # Responsible AI + security filter
│   ├── session.py           # Conversation session state in graph
│   └── findings.py          # Agent finding write-back
│
├── audit/
│   ├── logger.py            # Immutable audit log
│   └── pii_scanner.py       # PII detection on results
│
├── api/
│   ├── main.py              # FastAPI app entrypoint
│   ├── auth.py              # JWT + role extraction
│   ├── routes/
│   │   ├── query.py         # POST /v1/query
│   │   ├── context.py       # POST /v1/context
│   │   ├── agents.py        # GET  /v1/agent/{id}
│   │   ├── lineage.py       # GET  /v1/lineage/{asset}
│   │   ├── assert_facts.py  # POST /v1/assert
│   │   ├── session.py       # POST /v1/session
│   │   └── health.py        # GET  /v1/health/graph
│   └── middleware.py        # Rate limiting, audit injection
│
└── ui/
    └── app.py               # Streamlit enterprise chat UI
```

## Running

```bash
# API
uvicorn nexus.api.main:app --reload --port 8000

# UI
streamlit run nexus/ui/app.py
```
