"""
api/main.py — NEXUS FastAPI application.

Endpoints:
  POST /v1/query         — Natural language or SPARQL query
  POST /v1/context       — Entity context bundle for agents
  GET  /v1/agent/{id}    — Agent profile + tools
  GET  /v1/lineage/{id}  — Data lineage for an asset
  POST /v1/assert        — Write agent findings to graph
  POST /v1/session       — Create/update conversation session
  GET  /v1/health/graph  — Graph health metrics
"""
from __future__ import annotations
import time
import logging
from typing import Annotated, Any

from fastapi import FastAPI, Depends, HTTPException, Body, Path, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from nexus.api.auth import AuthenticatedUser, get_current_user, require_role
from nexus.api.middleware import RateLimitMiddleware
from nexus.config.settings import settings

logger = logging.getLogger(__name__)

# ── App ────────────────────────────────────────────────────────────────
app = FastAPI(
    title="NEXUS Enterprise Knowledge Graph API",
    version="1.0.0",
    description="Semantic intelligence layer for enterprise AI, agents, and orchestration.",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(RateLimitMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if not settings.is_production else ["https://nexus.internal"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request / Response models ──────────────────────────────────────────

class QueryRequest(BaseModel):
    question:              str  = Field(..., description="Natural language question")
    sparql:                str  = Field("", description="Raw SPARQL (skip NL translation if provided)")
    use_virtual_graph:     bool = Field(False, description="Include Denodo live data via virtual graph")
    session_id:            str  = Field("", description="Session ID for multi-turn context")
    clarification_context: str  = Field("", description="Confirmed context from human-in-the-loop step")


class QueryResponse(BaseModel):
    question:        str
    sparql:          str
    answer:          str
    columns:         list[str]
    rows:            list[dict]
    row_count:       int
    total_count:     int
    pii_detected:    bool
    redacted:        bool
    latency_ms:      int
    error:           str | None


class ContextRequest(BaseModel):
    entity: str = Field(..., description="Entity name or URI to fetch context for")


class AssertRequest(BaseModel):
    agent_id:    str
    label:       str
    severity:    str = "Medium"
    asset_uri:   str
    description: str


class SessionRequest(BaseModel):
    user_id:   str
    user_role: str = "analyst"


# ── POST /v1/query ─────────────────────────────────────────────────────

@app.post("/v1/query", response_model=QueryResponse, tags=["Query"])
async def query(
    req: QueryRequest,
    user: AuthenticatedUser = Depends(get_current_user),
):
    """
    Execute a natural language question against the NEXUS knowledge graph.
    Runs the full pipeline: guard → clarify → NL→SPARQL → execute → answer.
    """
    from nexus.agents.guard import check_intent, build_security_filter, RiskLevel
    from nexus.core.nl_to_sparql import nl_to_sparql
    from nexus.core.stardog_client import get_stardog
    from nexus.core.answer_engine import synthesise
    from nexus.audit.logger import log_query, log_guard_event
    from nexus.audit.pii_scanner import scan_and_redact

    t0 = time.monotonic()
    question = req.question.strip()

    # ── 1. Responsible AI pre-flight ─────────────────────────────
    guard = check_intent(question, user.user_role)
    log_guard_event(user.user_id, question, guard.allowed, guard.risk_level.value, guard.flags)

    if not guard.allowed:
        raise HTTPException(status_code=403, detail=f"Query blocked: {guard.reason}")

    # ── 2. Build security filter ─────────────────────────────────
    sec_filter = build_security_filter(user.user_role, user.department)

    # ── 3. Generate or use provided SPARQL ───────────────────────
    try:
        sparql = req.sparql or nl_to_sparql(
            question,
            clarification_context=req.clarification_context,
            user_role=user.user_role,
            use_virtual_graph=req.use_virtual_graph,
            extra_filters=sec_filter.sparql_data_filter,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"SPARQL generation failed: {exc}")

    # ── 4. Complexity check ───────────────────────────────────────
    db = get_stardog()
    complexity = db.estimate_complexity(sparql)
    hard_limit = max(settings.security.max_sparql_complexity, 25)
    if complexity > hard_limit:
        raise HTTPException(
            status_code=400,
            detail=f"Query complexity score {complexity} exceeds limit {hard_limit}. Simplify the question.",
        )

    # ── 5. Execute ────────────────────────────────────────────────
    try:
        raw = db.query(sparql)
        columns, rows = db.to_rows(raw)
    except Exception as exc:
        latency = int((time.monotonic() - t0) * 1000)
        log_query(user.user_id, user.user_role, req.session_id, question, sparql,
                  0, [], [], latency, settings.openai.sparql_model, str(exc))
        raise HTTPException(status_code=500, detail=f"Query execution failed: {exc}")

    # ── 6. Enforce row limit ──────────────────────────────────────
    total_count = len(rows)
    rows = rows[:sec_filter.max_rows]

    # ── 7. PII scan & redact ──────────────────────────────────────
    scan = scan_and_redact(rows, redact=True)
    classifications = list({r.get("classification", "") for r in rows if r.get("classification")})

    # ── 8. Synthesise NL answer ───────────────────────────────────
    answer = synthesise(question, columns, scan.redacted_rows, sparql, total_count)

    latency = int((time.monotonic() - t0) * 1000)
    log_query(
        user.user_id, user.user_role, req.session_id, question, sparql,
        len(rows), columns, classifications, latency, settings.openai.answer_model,
        pii_detected=scan.pii_found,
    )

    return QueryResponse(
        question     = question,
        sparql       = sparql,
        answer       = answer,
        columns      = columns,
        rows         = scan.redacted_rows,
        row_count    = len(scan.redacted_rows),
        total_count  = total_count,
        pii_detected = scan.pii_found,
        redacted     = scan.pii_found,
        latency_ms   = latency,
        error        = None,
    )


# ── POST /v1/context ───────────────────────────────────────────────────

@app.post("/v1/context", tags=["Agents"])
async def get_context(
    req: ContextRequest,
    user: AuthenticatedUser = Depends(get_current_user),
):
    """
    Get a rich context bundle for a named entity.
    Used by AI agents before acting on enterprise data.
    """
    from nexus.agents.context_provider import get_context
    from nexus.agents.guard import check_agent_permission
    from nexus.audit.logger import log_agent_action

    bundle = get_context(req.entity, requesting_agent=user.agent_id if user.is_agent else "")

    if user.is_agent and bundle.classification:
        perm = check_agent_permission(user.agent_id, bundle.domain, bundle.classification)
        log_agent_action(
            user.agent_id, "context_request", bundle.entity_uri,
            perm.permitted, perm.policy_applied, bundle.classification, bundle.domain,
        )
        if not perm.permitted:
            raise HTTPException(
                status_code=403,
                detail=f"Agent '{user.agent_id}' does not have permission to access "
                       f"{bundle.classification} data in domain '{bundle.domain}'. "
                       f"Reason: {perm.reason}",
            )

    return bundle.to_dict()


# ── GET /v1/agent/{agent_id} ───────────────────────────────────────────

@app.get("/v1/agent/{agent_id}", tags=["Agents"])
async def get_agent(
    agent_id: str = Path(..., description="Agent ID or name fragment"),
    user: AuthenticatedUser = Depends(get_current_user),
):
    """
    Get a registered AI agent's profile, tools, and permissions.
    Used by orchestration platforms before dispatching an agent.
    """
    from nexus.agents.registry import get_agent_profile, get_agent_tools

    profile = get_agent_profile(agent_id)
    if not profile:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found in NEXUS registry.")

    tools = get_agent_tools(agent_id)
    return {"profile": profile, "tools": tools}


# ── GET /v1/lineage/{asset} ────────────────────────────────────────────

@app.get("/v1/lineage/{asset}", tags=["Data"])
async def get_lineage(
    asset: str = Path(..., description="Asset name or URI fragment"),
    direction: str = Query("both", description="upstream | downstream | both"),
    depth: int = Query(3, ge=1, le=6, description="Traversal depth"),
    user: AuthenticatedUser = Depends(get_current_user),
):
    """
    Get upstream and/or downstream data lineage for an asset.
    Used for impact analysis, compliance tracing, and pipeline dependency mapping.
    """
    from nexus.core.stardog_client import get_stardog
    db = get_stardog()

    results = {}

    if direction in ("upstream", "both"):
        up_q = f"""
        SELECT ?asset ?assetLabel ?upstream ?upstreamLabel ?rel WHERE {{
            ?asset rdfs:label ?assetLabel .
            FILTER(CONTAINS(LCASE(STR(?assetLabel)), "{asset.lower()}"))
            ?asset (data:lineageFrom){{1,{depth}}} ?upstream .
            OPTIONAL {{ ?upstream rdfs:label ?upstreamLabel }}
        }} LIMIT 50
        """
        try:
            _, up_rows = db.to_rows(db.query(up_q))
            results["upstream"] = up_rows
        except Exception as exc:
            results["upstream"] = []
            results["upstream_error"] = str(exc)

    if direction in ("downstream", "both"):
        down_q = f"""
        SELECT ?asset ?assetLabel ?downstream ?downstreamLabel WHERE {{
            ?asset rdfs:label ?assetLabel .
            FILTER(CONTAINS(LCASE(STR(?assetLabel)), "{asset.lower()}"))
            ?downstream (data:lineageFrom){{1,{depth}}} ?asset .
            OPTIONAL {{ ?downstream rdfs:label ?downstreamLabel }}
        }} LIMIT 50
        """
        try:
            _, down_rows = db.to_rows(db.query(down_q))
            results["downstream"] = down_rows
        except Exception as exc:
            results["downstream"] = []
            results["downstream_error"] = str(exc)

    return {"asset": asset, "depth": depth, "lineage": results}


# ── POST /v1/assert ────────────────────────────────────────────────────

@app.post("/v1/assert", tags=["Agents"])
async def assert_finding(
    req: AssertRequest,
    user: AuthenticatedUser = Depends(get_current_user),
):
    """
    Write an agent finding to the NEXUS graph.
    Creates a permanent, attributed audit record of an agent's discovery.
    """
    from nexus.agents.findings import Finding, assert_finding as _assert
    from nexus.audit.logger import log_finding_asserted

    # Only agents or admins can assert findings
    if not user.is_agent and user.user_role not in ("admin", "data-steward"):
        raise HTTPException(status_code=403, detail="Only registered agents or admins may assert findings.")

    finding = Finding(
        agent_id    = req.agent_id or user.agent_id or user.user_id,
        label       = req.label,
        severity    = req.severity,
        asset_uri   = req.asset_uri,
        description = req.description,
    )

    try:
        uri = _assert(finding)
        log_finding_asserted(finding.agent_id, uri, finding.severity)
        return {"status": "asserted", "finding_uri": uri, "finding_id": finding.finding_id}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to assert finding: {exc}")


# ── POST /v1/session ───────────────────────────────────────────────────

@app.post("/v1/session", tags=["Session"])
async def create_or_update_session(
    req: SessionRequest,
    user: AuthenticatedUser = Depends(get_current_user),
):
    """Create a new conversation session in the NEXUS graph."""
    from nexus.agents.session import create_session

    try:
        session_id = create_session(req.user_id or user.user_id, req.user_role or user.user_role)
        return {"session_id": session_id, "status": "created"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── GET /v1/health/graph ───────────────────────────────────────────────

@app.get("/v1/health/graph", tags=["Operations"])
async def graph_health(
    user: AuthenticatedUser = Depends(require_role("admin", "analyst", "data-steward")),
):
    """Graph health, coverage, and freshness metrics."""
    from nexus.core.stardog_client import get_stardog
    db = get_stardog()

    metrics = {}
    checks = {
        "total_triples":    "SELECT (COUNT(*) AS ?count) WHERE { ?s ?p ?o }",
        "total_people":     "SELECT (COUNT(*) AS ?count) WHERE { ?s a hr:Person }",
        "total_apps":       "SELECT (COUNT(*) AS ?count) WHERE { ?s a app:Application }",
        "total_data_assets":"SELECT (COUNT(*) AS ?count) WHERE { ?s a data:DataAsset }",
        "total_agents":     "SELECT (COUNT(*) AS ?count) WHERE { ?s a agent:AIAgent }",
        "open_findings":    "SELECT (COUNT(*) AS ?count) WHERE { ?s a agent:AgentFinding ; agent:status 'Open' }",
        "orphaned_apps":    "SELECT (COUNT(*) AS ?count) WHERE { ?s a app:Application . FILTER NOT EXISTS { ?s app:techOwner ?o } }",
        "unclassified_assets": "SELECT (COUNT(*) AS ?count) WHERE { ?s a data:DataAsset . FILTER NOT EXISTS { ?s data:classification ?c } }",
    }

    for key, q in checks.items():
        try:
            _, rows = db.to_rows(db.query(q))
            metrics[key] = int(rows[0].get("count", 0)) if rows else 0
        except Exception as exc:
            metrics[key] = f"error: {exc}"

    return {
        "status": "healthy" if isinstance(metrics.get("total_triples"), int) else "degraded",
        "metrics": metrics,
    }
