"""
core/ontology.py — Loads and caches ontology context from the graph.
Used by the NL→SPARQL and clarification pipelines.
"""
from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

_CACHE_TTL_SECONDS = 3600  # Re-fetch ontology every hour


@dataclass
class OntologyContext:
    classes_text: str      = ""
    properties_text: str   = ""
    fetched_at: float      = 0.0

    @property
    def full_text(self) -> str:
        return f"Classes:\n{self.classes_text}\n\nProperties:\n{self.properties_text}"

    @property
    def is_stale(self) -> bool:
        return (time.time() - self.fetched_at) > _CACHE_TTL_SECONDS


_ctx = OntologyContext()


def _fetch() -> None:
    from nexus.core.stardog_client import get_stardog
    db = get_stardog()

    class_q = """
    SELECT DISTINCT ?class ?label ?comment WHERE {
        { ?class a owl:Class } UNION { ?class a rdfs:Class }
        OPTIONAL { ?class rdfs:label ?label    FILTER(LANG(?label)    = "en" || LANG(?label)    = "") }
        OPTIONAL { ?class rdfs:comment ?comment FILTER(LANG(?comment) = "en" || LANG(?comment) = "") }
    } LIMIT 200
    """
    prop_q = """
    SELECT DISTINCT ?prop ?label ?domain ?range WHERE {
        { ?prop a owl:ObjectProperty } UNION { ?prop a owl:DatatypeProperty }
        OPTIONAL { ?prop rdfs:label  ?label  }
        OPTIONAL { ?prop rdfs:domain ?domain }
        OPTIONAL { ?prop rdfs:range  ?range  }
    } LIMIT 200
    """

    try:
        _, class_rows = db.to_rows(db.query(class_q))
        _, prop_rows  = db.to_rows(db.query(prop_q))

        classes = []
        for r in class_rows:
            lbl = r.get("label") or r.get("class", "?").split("#")[-1].split("/")[-1]
            cmt = r.get("comment", "")
            classes.append(f"  - {lbl}" + (f": {cmt}" if cmt else ""))

        props = []
        for r in prop_rows:
            lbl = r.get("label", "?")
            dom = (r.get("domain") or "?").split("#")[-1].split("/")[-1]
            rng = (r.get("range")  or "?").split("#")[-1].split("/")[-1]
            props.append(f"  - {lbl}  ({dom} → {rng})")

        _ctx.classes_text    = "\n".join(classes) or "  (no classes found)"
        _ctx.properties_text = "\n".join(props)   or "  (no properties found)"
        _ctx.fetched_at      = time.time()
        logger.info("Ontology context refreshed: %d classes, %d properties", len(classes), len(props))

    except Exception as exc:
        logger.warning("Could not fetch ontology context: %s", exc)
        if not _ctx.classes_text:
            _ctx.classes_text    = "  (ontology unavailable)"
            _ctx.properties_text = "  (ontology unavailable)"
            _ctx.fetched_at      = time.time()


def get_ontology() -> OntologyContext:
    """Return (possibly cached) ontology context. Refreshes if stale."""
    if _ctx.is_stale:
        _fetch()
    return _ctx


def invalidate_ontology_cache() -> None:
    """Force refresh on next access."""
    _ctx.fetched_at = 0.0
