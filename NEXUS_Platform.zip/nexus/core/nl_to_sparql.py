"""
core/nl_to_sparql.py — Natural language -> SPARQL pipeline.
Tiered model strategy:
  o3-mini  -> SPARQL generation (reasoning model)
  gpt-4o   -> fallback
"""
from __future__ import annotations
import logging
import re
from openai import OpenAI

from nexus.config.settings import settings
from nexus.config.ontology_prefixes import DOMAIN_HINTS, SPARQL_PREFIX_BLOCK
from nexus.core.ontology import get_ontology

logger = logging.getLogger(__name__)

_client: OpenAI | None = None


def _openai() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(api_key=settings.openai.api_key)
    return _client


def _content(msg) -> str:
    c = msg.content if hasattr(msg, "content") else msg.get("content", "")
    if isinstance(c, list):
        return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in c)
    return str(c)


def nl_to_sparql(
    question: str,
    clarification_context: str = "",
    user_role: str = "analyst",
    use_virtual_graph: bool = False,
    extra_filters: str = "",
) -> str:
    ont = get_ontology()
    domain_hints = "\n".join(f"  {k}:\n    {v}" for k, v in DOMAIN_HINTS.items())

    clarification_block = (
        f"\nCONFIRMED CONTEXT FROM USER (use this to resolve ambiguity):\n{clarification_context}\n"
        if clarification_context else ""
    )

    extra_filter_hint = (
        f"\nINJECT THESE FILTER CLAUSES inside the WHERE block:\n{extra_filters}\n"
        if extra_filters else ""
    )

    system = f"""You are a SPARQL 1.1 expert generating queries for a Stardog enterprise knowledge graph.

{clarification_block}

DO NOT include any PREFIX declarations in your output — they are added automatically.
Only use these namespace shortcuts in your query body (e.g. ea:name, app:Application):
  ea / app / ai / hr / sec / uc / doc / entra / rdf / rdfs / owl / xsd

DOMAIN VOCABULARY:
{domain_hints}

ONTOLOGY SNAPSHOT:
{ont.full_text}

{extra_filter_hint}

STRICT SPARQL GENERATION RULES — violations cause HTTP 400 errors:

RULE 1 — NAME PROPERTIES
  Use ea:name for capabilities.  Use app:name for applications.  Use hr:fullName for people.
  Do NOT use rdfs:label — it is not populated in this graph.

RULE 2 — FILTER PLACEMENT
  FILTER must be INSIDE the WHERE {{ }} block, on its own line, after the triple it filters.
  NEVER place FILTER after the closing brace of WHERE.
  Correct:
    WHERE {{
      ?x a ea:BusinessCapabilityL1 ;
         ea:name ?name .
      FILTER(CONTAINS(LCASE(?name), "customer"))
    }}
  Wrong:
    WHERE {{ ?x a ea:BusinessCapabilityL1 ; ea:name ?name . }}
    FILTER(...)

RULE 3 — FILTER SYNTAX
  Always filter on the bound variable, not on the URI:
    CORRECT: ?x ea:name ?name . FILTER(CONTAINS(LCASE(?name), "customer"))
    WRONG:   FILTER(CONTAINS(LCASE(STR(?x)), "customer"))

RULE 4 — CAPABILITY HIERARCHY (two explicit hops, never skip)
  ?l1 a ea:BusinessCapabilityL1 ; ea:name ?l1Name .
  ?l1 ea:hasChildBusinessCapability ?l2 .
  ?l2 a ea:BusinessCapabilityL2 ; ea:name ?l2Name .
  ?l2 ea:hasChildBusinessCapability ?l3 .
  ?l3 a ea:BusinessCapabilityL3 ; ea:name ?l3Name .

RULE 5 — APPLICATION TO CAPABILITY LINK
  ?app a app:Application ;
       ea:enablesBusinessCapabilityL3 ?l3 ;
       app:name ?appName .
  Always wrap this in OPTIONAL so L3s with no app still appear.

RULE 6 — OPTIONAL SYNTAX
  OPTIONAL must be inside WHERE:
    WHERE {{
      ?x a ea:BusinessCapabilityL3 ; ea:name ?l3Name .
      OPTIONAL {{ ?app ea:enablesBusinessCapabilityL3 ?x ; app:name ?appName . }}
    }}

RULE 7 — STRUCTURE
  Every query must follow exactly this structure:
    PREFIX ...
    SELECT ...
    WHERE {{
      ... triples ...
      ... FILTERs inside here ...
      ... OPTIONALs inside here ...
    }}
    ORDER BY / LIMIT (optional, after the closing brace)

RULE 8 — OUTPUT
  Return ONLY the SPARQL query. No markdown fences, no explanation, no commentary.
  The first character of your response must be P (PREFIX) or S (SELECT).

RULE 9 — NEVER USE PLACEHOLDERS
  NEVER write placeholder strings like "Given L1 Capability Name", "CAPABILITY_NAME",
  "<name>", "your_value", or any other placeholder.
  If the user specified a name (e.g. "Customer Management"), use it directly:
    FILTER(CONTAINS(LCASE(?l1Name), "customer management"))
  If the user did NOT specify a name, omit the FILTER entirely and return ALL instances.
  A placeholder is worse than no filter — it returns zero rows every time.

RULE 10 — NEVER INJECT UNBOUND VARIABLES IN FILTER
  Only reference variables in FILTER that are actually bound by a triple pattern above.
  NEVER write: FILTER(!BOUND(?classification) || ...)
  unless ?classification is bound by a triple like: ?x data:classification ?classification .
"""

    logger.debug("nl_to_sparql: question=%r model=%s", question, settings.openai.sparql_model)

    for model in [settings.openai.sparql_model, "gpt-4o"]:
        try:
            resp = _openai().chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": (
                    f"Generate SPARQL for: {question}"
                    + (f"\n\nUser provided these specific values — use them directly in FILTER, not as placeholders:\n{clarification_context}" if clarification_context else "")
                )},
                ],
                temperature=0,
                max_tokens=settings.openai.max_tokens,
            )
            raw = _content(resp.choices[0].message).strip()
            logger.debug("nl_to_sparql raw (%s): %r", model, raw[:400])
            cleaned = _sanitise(raw)
            _validate(cleaned)   # raises if structurally broken
            return cleaned
        except _SparqlStructureError as exc:
            logger.warning("Model %s produced invalid SPARQL: %s — trying next model", model, exc)
            continue
        except Exception as exc:
            logger.warning("Model %s failed: %s — trying next model", model, exc)
            continue

    raise RuntimeError("All models failed to produce valid SPARQL.")


class _SparqlStructureError(Exception):
    pass


def _validate(sparql: str) -> None:
    """
    Lightweight structural validation before sending to Stardog.
    Catches the most common LLM generation errors.
    """
    upper = sparql.upper()

    # Must have WHERE
    if "WHERE" not in upper:
        raise _SparqlStructureError("Missing WHERE clause")

    # Detect unfilled placeholders — these always return zero rows
    placeholders = [
        "Given L1 Capability Name",
        "CAPABILITY_NAME",
        "YOUR_VALUE",
        "PLACEHOLDER",
        "<CAPABILITY",
        "<NAME",
        "your capability",
    ]
    for p in placeholders:
        if p.lower() in sparql.lower():
            raise _SparqlStructureError(
                f"Query contains placeholder '{p}' — LLM did not substitute real value"
            )

    # WHERE must have matching braces
    where_idx = upper.find("WHERE")
    after_where = sparql[where_idx:]
    depth = 0
    where_opened = False
    last_close = -1

    for i, ch in enumerate(after_where):
        if ch == "{":
            depth += 1
            where_opened = True
        elif ch == "}":
            depth -= 1
            if depth == 0 and where_opened:
                last_close = i

    # Check if FILTER appears after the WHERE closing brace
    if last_close > 0:
        after_close = after_where[last_close + 1:].upper().strip()
        if after_close.startswith("FILTER"):
            raise _SparqlStructureError(
                "FILTER found after WHERE closing brace — must be inside WHERE { }"
            )

    if not where_opened:
        raise _SparqlStructureError("WHERE block never opened")


def _sanitise(raw: str) -> str:
    """
    Strip markdown fences, preamble, and duplicate PREFIX declarations.
    Replaces all PREFIX lines the LLM generated with the canonical
    SPARQL_PREFIX_BLOCK so Stardog never sees a prefix declared twice.
    """
    if raw.startswith("[") and raw.endswith("]"):
        raw = raw[1:-1].strip().strip("'\"")
    raw = re.sub(r"^```[a-zA-Z]*\n?", "", raw)
    raw = re.sub(r"\n?```$", "", raw)
    raw = raw.strip()
    upper = raw.upper()
    for kw in ("PREFIX", "SELECT", "ASK", "CONSTRUCT", "DESCRIBE"):
        idx = upper.find(kw)
        if idx != -1:
            raw = raw[idx:]
            break
    # Remove all PREFIX lines — canonical block is prepended below
    lines = raw.splitlines()
    body = "\n".join(l for l in lines if not l.strip().upper().startswith("PREFIX")).strip()
    return f"{SPARQL_PREFIX_BLOCK}\n\n{body}"

