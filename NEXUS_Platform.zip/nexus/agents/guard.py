"""
agents/guard.py — Responsible AI pre-flight check + security filter.

Two responsibilities:
  1. ResponsibleAI check — screen the user's question for harmful intent BEFORE
     any query is generated. Uses gpt-4o-mini (fast, cheap classification).

  2. SecurityFilter — given the authenticated user's role and clearance,
     produce SPARQL FILTER clauses that enforce row-level security. These are
     injected into the nl_to_sparql prompt so the LLM generates a compliant query.
"""
from __future__ import annotations
import json
import logging
from dataclasses import dataclass
from enum import Enum

from openai import OpenAI
from nexus.config.settings import settings

logger = logging.getLogger(__name__)

_client: OpenAI | None = None


def _openai() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(api_key=settings.openai.api_key)
    return _client


def _content(msg) -> str:
    c = msg.content if hasattr(msg, "content") else msg.get("content", "")
    if isinstance(c, list):
        return "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in c)
    return str(c)


# ── Risk levels ────────────────────────────────────────────────────────

class RiskLevel(str, Enum):
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    BLOCKED  = "blocked"


@dataclass
class GuardResult:
    allowed:    bool
    risk_level: RiskLevel
    reason:     str
    flags:      list[str]

    @property
    def should_warn(self) -> bool:
        return self.risk_level in (RiskLevel.MEDIUM, RiskLevel.HIGH)


# ── Responsible AI pre-flight ──────────────────────────────────────────

_GUARD_SYSTEM = """You are a Responsible AI safety classifier for an enterprise knowledge graph.

Classify the user's question for risk. Return a JSON object:
{
  "allowed":    true | false,
  "risk_level": "low" | "medium" | "high" | "blocked",
  "reason":     "<one sentence>",
  "flags":      ["<flag>", ...]
}

BLOCK (allowed=false, blocked) when the question:
- Attempts bulk data exfiltration ("dump all", "export everything", "list all passwords")
- Attempts PII harvesting beyond a user's clearance
- Probes security vulnerabilities or attempts privilege escalation
- Requests data about a specific named individual in a discriminatory context
- Attempts to discover who has access to production credentials

HIGH RISK (allowed=true, high) when the question:
- Requests access certification status for all users
- Asks about sensitive data for a large population
- Crosses multiple security domains in a single query

MEDIUM RISK (allowed=true, medium) when:
- Requests PII fields (email, phone, salary)
- Queries agent permissions or AI system access rights
- Asks about security role assignments

LOW RISK everything else.

Return ONLY the JSON — no markdown, no preamble."""


def check_intent(question: str, user_role: str = "analyst") -> GuardResult:
    """
    Run the Responsible AI pre-flight check on a user's question.
    Call this BEFORE clarification or SPARQL generation.
    """
    try:
        resp = _openai().chat.completions.create(
            model=settings.openai.guard_model,
            messages=[
                {"role": "system", "content": _GUARD_SYSTEM},
                {"role": "user",   "content": f"User role: {user_role}\nQuestion: {question}"},
            ],
            temperature=0,
            max_tokens=300,
        )
        raw = _content(resp.choices[0].message).strip()

        import re
        raw = re.sub(r"^```[a-zA-Z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw).strip()

        data = json.loads(raw)
        return GuardResult(
            allowed    = bool(data.get("allowed", True)),
            risk_level = RiskLevel(data.get("risk_level", "low")),
            reason     = data.get("reason", ""),
            flags      = data.get("flags", []),
        )

    except Exception as exc:
        logger.warning("guard.check_intent() failed: %s — defaulting to allowed/low", exc)
        return GuardResult(allowed=True, risk_level=RiskLevel.LOW, reason="Guard check unavailable.", flags=[])


# ── Security filter (row-level security) ──────────────────────────────

# Maps role → what data classifications they can see
_CLASSIFICATION_CLEARANCE: dict[str, list[str]] = {
    "admin":        ["Public", "Internal", "Confidential", "Restricted"],
    "data-steward": ["Public", "Internal", "Confidential", "Restricted"],
    "analyst":      ["Public", "Internal"],
    "viewer":       ["Public"],
    "agent":        ["Public", "Internal"],           # AI agents default clearance
    "agent-admin":  ["Public", "Internal", "Confidential"],
}

# Maps role → HR domain scope (None = no restriction)
_HR_SCOPE: dict[str, str | None] = {
    "admin":        None,       # sees all people
    "data-steward": None,
    "analyst":      None,
    "viewer":       "own-dept", # can only see their own department
    "agent":        None,
    "agent-admin":  None,
}


@dataclass
class SecurityFilter:
    """
    Contains SPARQL FILTER clauses and result-level constraints for a role.
    Injected into nl_to_sparql and applied post-query.
    """
    allowed_classifications: list[str]
    sparql_data_filter: str    # injected into WHERE clause
    hr_scope: str | None       # None = no restriction
    max_rows: int


def build_security_filter(
    user_role: str,
    user_department: str = "",
    override_classification: list[str] | None = None,
) -> SecurityFilter:
    """
    Build row-level security filters for a given role.
    Called by the API auth layer before handing off to the query pipeline.
    """
    clearance = override_classification or _CLASSIFICATION_CLEARANCE.get(
        user_role, ["Public"]
    )
    hr_scope = _HR_SCOPE.get(user_role)

    # Build SPARQL filter for data classification
    if len(clearance) == 4:  # Admin sees all
        data_filter = ""
    else:
        vals = " ".join(f'"{c}"' for c in clearance)
        data_filter = (
            f"FILTER(!BOUND(?classification) || ?classification IN ({vals}))"
        )

    # Additional HR scope filter
    if hr_scope == "own-dept" and user_department:
        dept_filter = (
            f'\n  OPTIONAL {{ ?person hr:department ?dept }}'
            f'\n  FILTER(!BOUND(?dept) || STR(?dept) = "nexus.enterprise.com/hr#{user_department}")'
        )
        data_filter = (data_filter + dept_filter).strip()

    return SecurityFilter(
        allowed_classifications = clearance,
        sparql_data_filter      = data_filter,
        hr_scope                = hr_scope,
        max_rows                = settings.security.max_result_rows,
    )


# ── Agent-specific permission checker ─────────────────────────────────

@dataclass
class AgentPermissionResult:
    permitted:      bool
    agent_id:       str
    scope_matched:  bool
    policy_applied: str
    reason:         str


def check_agent_permission(
    agent_id: str,
    requested_domain: str,
    requested_classification: str,
) -> AgentPermissionResult:
    """
    Validate whether a named AI agent is permitted to access a given domain
    and data classification. Queries the NEXUS agent registry.
    """
    from nexus.agents.registry import get_agent_profile

    try:
        profile = get_agent_profile(agent_id)
        if profile is None:
            return AgentPermissionResult(
                permitted=False, agent_id=agent_id, scope_matched=False,
                policy_applied="deny-unknown-agent",
                reason=f"Agent '{agent_id}' is not registered in NEXUS.",
            )

        # Check domain scope
        scope_ok = (
            not profile.get("scopedDomains")  # no restriction = all domains
            or requested_domain in profile.get("scopedDomains", [])
        )

        # Check classification clearance
        agent_clearance = profile.get("clearanceLevel", "Internal")
        classification_rank = {"Public": 0, "Internal": 1, "Confidential": 2, "Restricted": 3}
        clearance_ok = (
            classification_rank.get(requested_classification, 99)
            <= classification_rank.get(agent_clearance, 1)
        )

        permitted = scope_ok and clearance_ok
        return AgentPermissionResult(
            permitted      = permitted,
            agent_id       = agent_id,
            scope_matched  = scope_ok,
            policy_applied = profile.get("policy", "default-agent-policy"),
            reason         = (
                "Permitted." if permitted
                else f"Denied: scope_ok={scope_ok}, clearance_ok={clearance_ok}, "
                     f"agent_clearance={agent_clearance}, requested={requested_classification}"
            ),
        )
    except Exception as exc:
        logger.error("check_agent_permission(%s) error: %s", agent_id, exc)
        return AgentPermissionResult(
            permitted=False, agent_id=agent_id, scope_matched=False,
            policy_applied="error-deny",
            reason=f"Permission check failed: {exc}",
        )
