"""
config/ontology_prefixes.py — Shared SPARQL prefix registry for all NEXUS domains.
Single source of truth — never hardcode prefixes elsewhere.

Namespaces are exactly those confirmed in the live Stardog graph TTL.
Do NOT add prefixes that do not exist in the graph — the LLM will hallucinate
properties under non-existent namespaces and queries will silently return empty.
"""

BASE = "http://example.com/"

PREFIXES: dict[str, str] = {
    # ── W3C core ───────────────────────────────────────────────────
    "rdf":   "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "rdfs":  "http://www.w3.org/2000/01/rdf-schema#",
    "owl":   "http://www.w3.org/2002/07/owl#",
    "xsd":   "http://www.w3.org/2001/XMLSchema#",

    # ── Confirmed in live graph (http://example.com/ base, hash namespaces) ──
    "ai":    f"{BASE}ai#",      # ai:Agent, ai:name, ai:status, ai:ownedByUser
    "app":   f"{BASE}app#",     # app:Application, app:name, app:techOwner
    "doc":   f"{BASE}doc#",     # doc:UnstructuredDocument
    "ea":    f"{BASE}ea#",      # ea:BusinessCapabilityL1/L2/L3, ea:name,
                                #   ea:hasChildBusinessCapability,
                                #   ea:enablesBusinessCapabilityL3,
                                #   ea:TechnologyCapability*, ea:CSOCapability*,
                                #   ea:EADomain*, ea:Technology
    "entra": f"{BASE}entra#",   # entra:EntraIdentity, entra:clientId
    "hr":    f"{BASE}hr#",      # hr:User, hr:Manager, hr:Department, hr:fullName
    "sec":   f"{BASE}sec#",     # sec:AccessRight, sec:SecurityPolicy, sec:DataClassification
    "uc":    f"{BASE}uc#",      # uc:View
}

# Pre-built PREFIX block injected at the top of every generated SPARQL query
SPARQL_PREFIX_BLOCK: str = "\n".join(
    f"PREFIX {k}: <{v}>" for k, v in PREFIXES.items()
)

# ── Domain hints for the NL->SPARQL LLM prompt ────────────────────────
# Rules enforced in every hint:
#   1. Use ea:name / app:name / ai:name / hr:fullName — NOT rdfs:label
#   2. Always declare the rdf:type triple (?x a ea:BusinessCapabilityL1)
#   3. Hierarchy traversal is always explicit two-hop (L1->L2->L3), never skipped
#   4. App->L3 link subject is the app, object is the L3 capability

DOMAIN_HINTS: dict[str, str] = {

    "people": (
        "Classes:  hr:User  hr:Manager (subClassOf hr:User)  hr:Department  hr:Role\n"
        "Properties:\n"
        "  hr:fullName            — person display name (NOT rdfs:label)\n"
        "  hr:mail                — email address\n"
        "  hr:employeeId          — internal employee ID\n"
        "  hr:employmentStatus    — Active | Leaver | OnLeave | Contractor\n"
        "  hr:manager             — User -> User (direct line manager)\n"
        "  hr:managerOf           — Manager -> User (inverse of hr:manager)\n"
        "  hr:belongsToDepartment — User -> Department\n"
        "  hr:hasRole             — User -> Role\n"
        "  hr:parentDepartment    — Department -> parent Department\n"
        "  hr:childDepartment     — Department -> child Department\n"
        "  hr:inOrganization      — Department -> hr:Organization"
    ),

    "architecture_business": (
        "Classes:  ea:BusinessCapabilityL1  ea:BusinessCapabilityL2  ea:BusinessCapabilityL3\n"
        "  (all subClassOf ea:BusinessCapability — always use the specific typed class)\n"
        "Properties:\n"
        "  ea:name                       — capability display name (NOT rdfs:label)\n"
        "  ea:description                — capability description\n"
        "  ea:strategicIntent            — Invest | Maintain | Retire | Tolerate\n"
        "  ea:hasChildBusinessCapability — parent->child, ONE HOP PER LEVEL\n"
        "    Correct pattern:\n"
        "      ?l1 a ea:BusinessCapabilityL1 ; ea:name ?l1Name .\n"
        "      ?l1 ea:hasChildBusinessCapability ?l2 .\n"
        "      ?l2 a ea:BusinessCapabilityL2     ; ea:name ?l2Name .\n"
        "      ?l2 ea:hasChildBusinessCapability ?l3 .\n"
        "      ?l3 a ea:BusinessCapabilityL3     ; ea:name ?l3Name .\n"
        "  ea:isChildBusinessCapabilityOf — child->parent (inverse)\n"
        "  ea:hasBusinessCapabilityL1     — EABusinessDomain -> BusinessCapabilityL1\n"
        "NEVER skip levels. NEVER use ea:businessParentOf (removed)."
    ),

    "architecture_app_capability": (
        "Linking applications to L3 capabilities:\n"
        "  ea:enablesBusinessCapabilityL3  — app:Application -> ea:BusinessCapabilityL3\n"
        "    Correct pattern:  ?app a app:Application ;\n"
        "                           ea:enablesBusinessCapabilityL3 ?l3 ;\n"
        "                           app:name ?appName .\n"
        "  ea:isEnabledByApplication       — inverse (L3 -> Application)\n"
        "  Always wrap the app block in OPTIONAL so L3s without apps still appear."
    ),

    "architecture_technology": (
        "Classes:  ea:TechnologyCapabilityL1  ea:TechnologyCapabilityL2  ea:TechnologyCapabilityL3\n"
        "          ea:Technology  ea:EATechnologyDomain\n"
        "Properties:\n"
        "  ea:name                           — capability name\n"
        "  ea:technologyName                 — technology product name\n"
        "  ea:hasChildTechnologyCapability   — parent->child hierarchy\n"
        "  ea:enablesTechnologyCapabilityL3  — Technology -> TechnologyCapabilityL3\n"
        "  app:usesTechnology                — Application -> Technology"
    ),

    "architecture_cso": (
        "Classes:  ea:CSOCapabilityL1  ea:CSOCapabilityL2  ea:CSOCapabilityL3  ea:EACSODomain\n"
        "Properties:\n"
        "  ea:name                   — capability name\n"
        "  ea:hasChildCSOCapability  — parent->child hierarchy\n"
        "  ea:enablesCSOCapabilityL3 — Technology -> CSOCapabilityL3"
    ),

    "architecture_domain": (
        "Classes:  ea:EADomain  ea:EABusinessDomain  ea:EATechnologyDomain  ea:EACSODomain\n"
        "Properties:\n"
        "  ea:name                      — domain display name\n"
        "  ea:hasBusinessCapabilityL1   — EABusinessDomain -> BusinessCapabilityL1\n"
        "  ea:hasTechnologyCapabilityL1 — EATechnologyDomain -> TechnologyCapabilityL1\n"
        "  ea:hasCSOCapabilityL1        — EACSODomain -> CSOCapabilityL1"
    ),

    "applications": (
        "Classes:  app:Application\n"
        "Properties:\n"
        "  app:name             — application display name (NOT rdfs:label)\n"
        "  app:uciid            — unique CI identifier from CMDB\n"
        "  app:environment      — DEV | TEST | PROD\n"
        "  app:lifecycleStatus  — Active | Retiring | Retired | UnderAssessment\n"
        "  app:techOwner        — Application -> hr:User\n"
        "  app:businessOwner    — Application -> hr:User\n"
        "  app:departmentOwner  — Application -> hr:Department\n"
        "  app:usesTechnology   — Application -> ea:Technology\n"
        "  ea:strategicIntent   — Invest | Maintain | Retire | Tolerate"
    ),

    "security": (
        "Classes:  sec:AccessRight  sec:SecurityPolicy  sec:DataClassification\n"
        "Properties:\n"
        "  sec:hasAccessRight        — ai:Agent -> sec:AccessRight\n"
        "  sec:userHasAccessRight    — hr:User  -> sec:AccessRight\n"
        "  sec:governedBy            — AccessRight -> SecurityPolicy\n"
        "  sec:constrainsIdentity    — SecurityPolicy -> entra:EntraIdentity\n"
        "  sec:accessesDocument      — AccessRight -> doc:UnstructuredDocument\n"
        "  sec:accessesView          — AccessRight -> uc:View\n"
        "  sec:userCanAccessDocument — hr:User -> doc:UnstructuredDocument\n"
        "  sec:userCanAccessView     — hr:User -> uc:View\n"
        "  sec:classificationLevel   — Public | Internal | Confidential | Restricted\n"
        "  sec:policyTags            — policy tag string"
    ),

    "agents": (
        "Classes:  ai:Agent\n"
        "Properties:\n"
        "  ai:name                  — agent display name\n"
        "  ai:description           — agent description\n"
        "  ai:status                — Active | Inactive | UnderReview\n"
        "  ai:environment           — DEV | TEST | PROD\n"
        "  ai:capabilities          — capabilities text\n"
        "  ai:instructions          — instructions text\n"
        "  ai:tools                 — tools text\n"
        "  ai:owner                 — plain-text owner name\n"
        "  ai:ownedByUser           — ai:Agent -> hr:User\n"
        "  ai:supportedByDepartment — ai:Agent -> hr:Department\n"
        "  ai:usesApplication       — ai:Agent -> app:Application\n"
        "  entra:hasEntraIdentity   — ai:Agent -> entra:EntraIdentity\n"
        "  sec:hasAccessRight       — ai:Agent -> sec:AccessRight"
    ),

    "identity": (
        "Classes:  entra:EntraIdentity\n"
        "Properties:\n"
        "  entra:objectId  — Entra object ID\n"
        "  entra:clientId  — app/client ID\n"
        "  entra:tenantId  — tenant ID\n"
        "  entra:scopes    — OAuth scopes\n"
        "  entra:appRoles  — app roles"
    ),

    "documents": (
        "Classes:  doc:UnstructuredDocument\n"
        "Properties:\n"
        "  sec:accessesDocument      — AccessRight -> UnstructuredDocument\n"
        "  sec:userCanAccessDocument — User -> UnstructuredDocument"
    ),

    "data": (
        "Classes:  uc:View\n"
        "Properties:\n"
        "  sec:accessesView      — AccessRight -> uc:View\n"
        "  sec:userCanAccessView — User -> uc:View"
    ),
}
