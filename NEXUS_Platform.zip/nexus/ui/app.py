"""
ui/app.py - NEXUS Enterprise Conversational AI
Full pipeline: guard -> clarify -> confirm -> query -> answer + reasoning
"""
import os, time, json, logging, sys
import streamlit as st
import pandas as pd
from dotenv import load_dotenv
load_dotenv()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
logging.basicConfig(level=logging.WARNING)

st.set_page_config(page_title="NEXUS", page_icon="🔮", layout="wide", initial_sidebar_state="expanded")

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
html,body,[class*="css"]{font-family:'DM Sans',sans-serif;}
code,.stCode,pre{font-family:'DM Mono',monospace;}
.stApp{background:#060d1a;}
section[data-testid="stSidebar"]{background:#080f1e!important;border-right:1px solid #1a2744;}
.nexus-header{background:linear-gradient(135deg,#0a1628 0%,#0d2044 50%,#091830 100%);border:1px solid #1e3a6e;border-radius:12px;padding:1.4rem 2rem;margin-bottom:1.2rem;position:relative;overflow:hidden;}
.nexus-header::before{content:"";position:absolute;inset:0;background:radial-gradient(ellipse at 70% 50%,rgba(46,117,182,.12) 0%,transparent 70%);pointer-events:none;}
.nexus-title{font-size:1.7rem;font-weight:700;background:linear-gradient(90deg,#e8f0fe 0%,#93c5fd 50%,#60a5fa 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin:0;line-height:1.2;}
.nexus-sub{color:#64748b;font-size:.82rem;margin:.3rem 0 0;font-weight:400;}
.plan-card{background:#0a1628;border:1px solid #1e3a6e;border-top:3px solid #2e75b6;border-radius:8px;padding:1rem 1.2rem;margin:.6rem 0;}
.plan-label{font-size:.72rem;font-weight:600;letter-spacing:.08em;color:#2e75b6;text-transform:uppercase;margin-bottom:.3rem;}
.plan-value{font-size:.85rem;color:#cbd5e1;}
.plan-tag{display:inline-block;background:#0d2044;border:1px solid #1e3a6e;border-radius:4px;padding:.15rem .5rem;font-size:.75rem;color:#93c5fd;margin:.15rem .15rem 0 0;font-family:'DM Mono',monospace;}
.plan-warn{background:#1a0a08;border:1px solid #7c2d12;border-radius:6px;padding:.6rem .8rem;margin-top:.5rem;font-size:.8rem;color:#fca5a5;}
.risk-low{background:#052e16;color:#86efac;border:1px solid #166534;border-radius:4px;padding:.1rem .5rem;font-size:.72rem;font-weight:600;}
.risk-medium{background:#1c1206;color:#fcd34d;border:1px solid #78350f;border-radius:4px;padding:.1rem .5rem;font-size:.72rem;font-weight:600;}
.risk-high{background:#1a0a08;color:#fca5a5;border:1px solid #7c2d12;border-radius:4px;padding:.1rem .5rem;font-size:.72rem;font-weight:600;}
.risk-blocked{background:#3b0764;color:#e879f9;border:1px solid #7e22ce;border-radius:4px;padding:.1rem .5rem;font-size:.72rem;font-weight:600;}
.confidence-bar{height:4px;border-radius:2px;background:linear-gradient(90deg,#2e75b6,#60a5fa);margin-top:4px;}
details summary{color:#64748b!important;font-size:.8rem!important;}
details[open] summary{color:#93c5fd!important;}
.stChatInput>div{background:#0a1628!important;border-color:#1e3a6e!important;}
.stButton>button{background:#0d2044;border:1px solid #2e75b6;color:#93c5fd;border-radius:6px;font-size:.82rem;transition:all .15s;}
.stButton>button:hover{background:#1e3a6e;border-color:#60a5fa;color:#e2e8f0;}
.stToggle>label{color:#94a3b8!important;font-size:.82rem!important;}
::-webkit-scrollbar{width:4px;}
::-webkit-scrollbar-track{background:#060d1a;}
::-webkit-scrollbar-thumb{background:#1e3a6e;border-radius:2px;}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

# Session state
for k, v in {"messages":[],"connected":False,"session_id":"","pending_plan":None,
              "pending_question":"","pending_clarification":"","turn_count":0}.items():
    if k not in st.session_state:
        st.session_state[k] = v

@st.cache_resource(show_spinner=False)
def make_client(endpoint, token, oai_key, db):
    os.environ.update({"STARDOG_ENDPOINT":endpoint,"STARDOG_TOKEN":token,
                       "OPENAI_API_KEY":oai_key,"STARDOG_DB":db})
    from nexus.core.stardog_client import StardogClient
    return StardogClient()

# ── Sidebar ────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div style="text-align:center;padding:.5rem 0 1rem"><span style="font-size:1.8rem">🔮</span><div style="color:#60a5fa;font-weight:700;font-size:1rem;margin-top:.2rem">NEXUS</div><div style="color:#475569;font-size:.7rem">Knowledge Graph Platform</div></div>', unsafe_allow_html=True)

    with st.expander("Stardog Connection", expanded=not st.session_state.connected):
        endpoint   = st.text_input("Endpoint", value=os.getenv("STARDOG_ENDPOINT","http://localhost:5820/nexus/query"))
        token      = st.text_input("Token", type="password", value=os.getenv("STARDOG_TOKEN",""))
        db_name    = st.text_input("Database", value=os.getenv("STARDOG_DB","nexus"))

    with st.expander("OpenAI", expanded=not st.session_state.connected):
        openai_key    = st.text_input("API Key", type="password", value=os.getenv("OPENAI_API_KEY",""))
        sparql_model  = st.selectbox("SPARQL Model", ["o3-mini","gpt-4o","gpt-4o-mini"])
        answer_model  = st.selectbox("Answer Model", ["gpt-4o","gpt-4o-mini","o3-mini"])

    if st.button("Connect", use_container_width=True):
        if endpoint and openai_key:
            try:
                os.environ.update({"SPARQL_MODEL":sparql_model,"ANSWER_MODEL":answer_model})
                make_client(endpoint, token, openai_key, db_name)
                from nexus.agents.session import create_session
                st.session_state.session_id = create_session("ui-user","analyst")
                st.session_state.connected = True
                st.success("Connected")
            except Exception as e:
                st.error(f"Failed: {e}"); st.session_state.connected = False
        else:
            st.warning("Endpoint and API key required.")

    st.divider()
    st.markdown('<div style="color:#64748b;font-size:.7rem;font-weight:600;letter-spacing:.05em;text-transform:uppercase;margin-bottom:.4rem">Query Options</div>', unsafe_allow_html=True)
    use_virtual  = st.toggle("Denodo Virtual Graph", value=False)
    show_sparql  = st.toggle("Show SPARQL", value=True)
    show_table   = st.toggle("Show Results Table", value=True)
    show_plan    = st.toggle("Show Query Plan", value=True)
    auto_confirm = st.toggle("Auto-confirm (skip HitL)", value=False)
    st.divider()
    st.markdown('<div style="color:#64748b;font-size:.7rem;font-weight:600;letter-spacing:.05em;text-transform:uppercase;margin-bottom:.4rem">Identity</div>', unsafe_allow_html=True)
    user_role = st.selectbox("Role", ["analyst","data-steward","admin","viewer","agent"])
    user_dept = st.text_input("Department", value="", placeholder="e.g. Finance")
    st.divider()

    if st.button("Refresh Graph Health", use_container_width=True):
        if st.session_state.connected:
            from nexus.core.stardog_client import get_stardog
            db = get_stardog()
            checks = {"People":"SELECT (COUNT(*) AS ?c) WHERE { ?s a hr:Person }",
                      "Apps":"SELECT (COUNT(*) AS ?c) WHERE { ?s a app:Application }",
                      "Data Assets":"SELECT (COUNT(*) AS ?c) WHERE { ?s a data:DataAsset }",
                      "AI Agents":"SELECT (COUNT(*) AS ?c) WHERE { ?s a agent:AIAgent }",
                      "Open Findings":"SELECT (COUNT(*) AS ?c) WHERE { ?s a agent:AgentFinding ; agent:status 'Open' }"}
            for lbl, q in checks.items():
                try:
                    _, rows = db.to_rows(db.query(q))
                    st.metric(lbl, rows[0].get("c","?") if rows else "?")
                except:
                    st.metric(lbl, "err")

    if st.button("Clear Chat", use_container_width=True):
        st.session_state.update({"messages":[],"pending_plan":None,"pending_question":"","turn_count":0})
        st.rerun()
    st.caption("NEXUS v1.0 - Stardog + OpenAI")

# ── Header ─────────────────────────────────────────────────────────────
dot = '<span style="color:#22c55e">●</span>' if st.session_state.connected else '<span style="color:#ef4444">●</span>'
status_txt = "Connected" if st.session_state.connected else "Disconnected"
sid = st.session_state.session_id[:12] if st.session_state.session_id else "none"

st.markdown(
    '<div class="nexus-header">'
    '<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:.5rem">'
    '<div><div class="nexus-title">NEXUS - Enterprise Knowledge Graph</div>'
    '<div class="nexus-sub">Conversational AI - Agent Grounding - Orchestration Intelligence - Semantic Governance</div></div>'
    f'<div style="text-align:right;font-size:.78rem;color:#475569">{dot} {status_txt} &nbsp;·&nbsp; {user_role.title()} &nbsp;·&nbsp; Session {sid}</div>'
    '</div></div>',
    unsafe_allow_html=True
)

# ── Examples ───────────────────────────────────────────────────────────
EXAMPLES = [
    "Which AI agents have access to Restricted data and haven't been reviewed in 90 days?",
    "Who are the direct and indirect reports of the CTO with privileged production access?",
    "Which data assets contain PII with no steward assigned?",
    "Show all applications with no business capability realisation in Orbus",
    "Which access certifications are overdue for Finance with SOX-regulated data?",
    "Which n8n pipelines write to Restricted data assets with no documented procedure?",
]

if not st.session_state.messages and not st.session_state.pending_plan:
    st.markdown('<div style="color:#475569;font-size:.78rem;font-weight:600;letter-spacing:.05em;text-transform:uppercase;margin-bottom:.6rem">Example Questions</div>', unsafe_allow_html=True)
    cols = st.columns(3)
    for i, ex in enumerate(EXAMPLES):
        if cols[i % 3].button(ex[:58] + ("..." if len(ex) > 58 else ""), key=f"ex_{i}", use_container_width=True):
            st.session_state["prefill"] = ex
            st.rerun()

# ── Chat history ───────────────────────────────────────────────────────
for msg in st.session_state.messages:
    role = msg["role"]
    avatar = "🔮" if role == "assistant" else "👤"
    with st.chat_message(role, avatar=avatar):
        st.markdown(msg["content"])
        if show_sparql and msg.get("sparql"):
            with st.expander("Generated SPARQL"):
                st.code(msg["sparql"], language="sparql")
        if show_table and msg.get("rows"):
            st.dataframe(pd.DataFrame(msg["rows"]), use_container_width=True, hide_index=True)
        if msg.get("latency_ms"):
            st.caption(f"{msg['latency_ms']}ms · {msg.get('row_count',0)} rows · {msg.get('model','')}")

# ── Render plan ────────────────────────────────────────────────────────
def render_plan(plan):
    risk = getattr(plan, "risk_level", "low")
    risk_class = {"low":"risk-low","medium":"risk-medium","high":"risk-high","blocked":"risk-blocked"}.get(risk,"risk-low")
    conf = int(getattr(plan, "confidence", 1.0) * 100)
    conf_col = "#22c55e" if conf > 80 else "#fcd34d" if conf > 50 else "#ef4444"

    def tags(items):
        return "".join(f'<span class="plan-tag">{i}</span>' for i in items) or "<span style='color:#475569'>none</span>"

    warn_html = ""
    if getattr(plan, "security_notes", []):
        notes = "".join(f"<div>- {n}</div>" for n in plan.security_notes)
        warn_html = f'<div class="plan-warn">Security notes:<br>{notes}</div>'

    assump_html = ""
    if getattr(plan, "assumptions", []):
        items = "".join(f"<div style='color:#94a3b8;font-size:.8rem;margin-top:.2rem'>- {a}</div>" for a in plan.assumptions)
        assump_html = f'<div style="margin-top:.6rem"><div class="plan-label">Assumptions</div>{items}</div>'

    html = (
        '<div class="plan-card">'
        f'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem">'
        f'<span style="color:#60a5fa;font-weight:600;font-size:.9rem">Query Plan</span>'
        f'<span class="{risk_class}">RISK: {risk.upper()}</span></div>'
        f'<div class="plan-label">Interpreted Intent</div>'
        f'<div class="plan-value">{getattr(plan,"interpreted_intent","")}</div>'
        f'<div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;margin-top:.6rem">'
        f'<div><div class="plan-label">Domains</div>{tags(getattr(plan,"domains_involved",[]))}</div>'
        f'<div><div class="plan-label">Confidence</div>'
        f'<div style="color:{conf_col};font-weight:600;font-size:.85rem">{conf}%</div>'
        f'<div class="confidence-bar" style="width:{conf}%;background:{conf_col}88"></div></div></div>'
        f'<div style="margin-top:.6rem"><div class="plan-label">Entities</div>{tags(getattr(plan,"mapped_entities",[]))}</div>'
        f'<div style="margin-top:.4rem"><div class="plan-label">Relationships</div>{tags(getattr(plan,"mapped_relationships",[]))}</div>'
        f'{assump_html}{warn_html}'
        '</div>'
    )
    st.markdown(html, unsafe_allow_html=True)

# ── Execute pipeline ───────────────────────────────────────────────────
def execute_query(question, clarification_context=""):
    from nexus.agents.guard       import check_intent, build_security_filter
    from nexus.core.nl_to_sparql  import nl_to_sparql
    from nexus.core.stardog_client import get_stardog
    from nexus.core.answer_engine  import synthesise
    from nexus.audit.logger        import log_query, log_guard_event
    from nexus.audit.pii_scanner   import scan_and_redact
    from nexus.config.settings     import settings as _s

    t0 = time.monotonic()
    with st.chat_message("assistant", avatar="🔮"):
        status = st.empty()

        # Guard
        status.markdown("Responsible AI check...")
        guard = check_intent(question, user_role)
        log_guard_event("ui-user", question, guard.allowed, guard.risk_level.value, guard.flags)
        if not guard.allowed:
            msg = f"Blocked: {guard.reason}"
            if guard.flags: msg += " | Flags: " + ", ".join(guard.flags)
            status.markdown(msg)
            st.session_state.messages.append({"role":"assistant","content":msg})
            return
        if guard.risk_level.value in ("medium","high"):
            st.warning(f"Risk {guard.risk_level.value.upper()}: {guard.reason}")

        # Security filter
        sec = build_security_filter(user_role, user_dept)

        # SPARQL
        status.markdown("Generating SPARQL...")
        try:
            sparql = nl_to_sparql(question, clarification_context=clarification_context,
                                  user_role=user_role, use_virtual_graph=use_virtual,
                                  extra_filters=sec.sparql_data_filter)
        except Exception as exc:
            msg = f"SPARQL generation failed: {exc}"
            status.markdown(msg); st.session_state.messages.append({"role":"assistant","content":msg}); return

        # Complexity
        db = get_stardog()
        complexity = db.estimate_complexity(sparql)
        hard_limit = max(_s.security.max_sparql_complexity, 25)
        if complexity > hard_limit:
            msg = f"Query complexity {complexity} exceeds limit {hard_limit}. Simplify."
            status.markdown(msg); st.session_state.messages.append({"role":"assistant","content":msg}); return

        # Execute
        status.markdown("Querying knowledge graph...")
        try:
            raw = db.query(sparql)
            columns, rows = db.to_rows(raw)
        except Exception as exc:
            msg = f"Query failed: {exc}"
            status.markdown(msg); st.session_state.messages.append({"role":"assistant","content":msg}); return

        total = len(rows)
        rows  = rows[:sec.max_rows]
        scan  = scan_and_redact(rows, redact=True)
        classifications = list({r.get("classification","") for r in rows if r.get("classification")})

        # Answer
        status.markdown("Synthesising answer...")
        answer = synthesise(question, columns, scan.redacted_rows, sparql, total)
        latency = int((time.monotonic() - t0) * 1000)
        log_query("ui-user", user_role, st.session_state.session_id, question, sparql,
                  len(rows), columns, classifications, latency, _s.openai.answer_model,
                  pii_detected=scan.pii_found)

        # Render
        status.empty()
        if scan.pii_found:
            det = ", ".join(f"{d['field']} ({d['type']})" for d in scan.detections)
            st.info(f"PII detected and redacted: {det}")

        st.markdown(answer)

        if show_sparql:
            with st.expander("Generated SPARQL"):
                st.code(sparql, language="sparql")
        if show_table and scan.redacted_rows:
            label = f"Results - {total} rows"
            if total > sec.max_rows: label += f" (showing {sec.max_rows})"
            with st.expander(label):
                st.dataframe(pd.DataFrame(scan.redacted_rows), use_container_width=True, hide_index=True)

        st.caption(f"{latency}ms - {total} rows" +
                   (" - PII redacted" if scan.pii_found else "") +
                   f" - complexity:{complexity} - {_s.openai.answer_model}")

        st.session_state.messages.append({"role":"assistant","content":answer,
            "sparql":sparql,"rows":scan.redacted_rows[:50],
            "row_count":total,"latency_ms":latency,"model":_s.openai.answer_model})
        st.session_state.turn_count += 1

# ── HitL plan confirmation ─────────────────────────────────────────────
def handle_pending():
    plan     = st.session_state.pending_plan
    question = st.session_state.pending_question
    if show_plan: render_plan(plan)
    cqs = getattr(plan, "clarifying_questions", [])
    with st.chat_message("assistant", avatar="🔮"):
        if cqs and not getattr(plan,"ready_to_execute",True) and not auto_confirm:
            st.markdown("Please clarify before I run this query:")
            answers = []
            with st.form("clarify_form", clear_on_submit=True):
                for i, cq in enumerate(cqs[:2]):
                    answers.append(st.text_input(f"Q{i+1}: {cq}", key=f"cq_ans_{i}"))
                c1, c2 = st.columns(2)
                submitted = c1.form_submit_button("Submit & Run", use_container_width=True)
                skipped   = c2.form_submit_button("Skip & Run",   use_container_width=True)
            if submitted or skipped:
                ctx = ""
                if submitted and any(a.strip() for a in answers):
                    ctx = "\n\n".join(f"Q: {cqs[i]}\nA: {answers[i]}" for i in range(len(cqs))
                                      if i < len(answers) and answers[i].strip())
                st.session_state.pending_plan = None
                st.session_state.pending_question = ""
                execute_query(question, ctx)
        else:
            if not auto_confirm:
                st.markdown("Query plan confirmed. Ready to execute.")
                c1, c2 = st.columns(2)
                if c1.button("Run Query",     use_container_width=True, key="btn_run"):
                    st.session_state.pending_plan = None
                    execute_query(question, st.session_state.pending_clarification)
                if c2.button("Edit Question", use_container_width=True, key="btn_edit"):
                    st.session_state.pending_plan = None
                    st.session_state.pending_question = ""
                    st.rerun()
            else:
                st.session_state.pending_plan = None
                execute_query(question, st.session_state.pending_clarification)

if st.session_state.pending_plan:
    handle_pending()

# ── Chat input ─────────────────────────────────────────────────────────
prefill  = st.session_state.pop("prefill", "")
question = st.chat_input("Ask NEXUS anything about your enterprise...") or prefill

if question and not st.session_state.pending_plan:
    st.session_state.messages.append({"role":"user","content":question})
    with st.chat_message("user", avatar="👤"):
        st.markdown(question)

    if not st.session_state.connected:
        with st.chat_message("assistant", avatar="🔮"):
            st.warning("Connect to NEXUS via the sidebar first.")
    else:
        with st.chat_message("assistant", avatar="🔮"):
            with st.spinner("Mapping to ontology..."):
                try:
                    from nexus.core.clarifier import clarify
                    from nexus.agents.guard   import check_intent
                    guard = check_intent(question, user_role)
                    if not guard.allowed:
                        msg = f"Blocked: {guard.reason}"
                        st.markdown(msg)
                        st.session_state.messages.append({"role":"assistant","content":msg})
                        st.stop()
                    if auto_confirm:
                        st.session_state.pending_plan = None
                        execute_query(question)
                    else:
                        plan = clarify(question, user_role)
                        plan.risk_level = guard.risk_level.value
                        st.session_state.pending_plan = plan
                        st.session_state.pending_question = question
                        st.session_state.pending_clarification = ""
                        st.rerun()
                except Exception as exc:
                    st.error(f"Clarification failed ({exc}). Running directly.")
                    execute_query(question)
